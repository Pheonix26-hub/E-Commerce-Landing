# E-Commerce Landing Page Example

A Pen created on CodePen.

Original URL: [https://codepen.io/leonam-silva-de-souza/pen/NWQeqJR](https://codepen.io/leonam-silva-de-souza/pen/NWQeqJR).

Source: codewithsadee (https://www.youtube.com/watch?v=3l8Lob4ysI0)